<div class="section-<?php echo $pluginName ?>"><!-- $pluginName - задает название секции для разграничения JS скрипта -->

  <!-- Тут начинается верстка видимой части станицы настроек плагина-->
  <div class="widget-table-body">
    
     <div class="widget-table-action">
       <div class="sitemap-msg"><?php echo $msg ?></div>  
       <br/>
       <br/>
       <a href="javascript:void(0);" class="add-new-button tool-tip-top button success" title=""><span><i class="fa fa-plus-circle"></i> Создать карту</span></a>
       <div class="clear"></div>
      </div>      
     
  </div>
</div>

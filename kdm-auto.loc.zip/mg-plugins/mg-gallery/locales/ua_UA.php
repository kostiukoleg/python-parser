<?php
$lang = array(
  "DIR_NOT_FOUND" => 'Директорія не знайдено',
  "NOT_TEMPLATE_FILE" => 'Не знайдений файл шаблону плагіна',
);
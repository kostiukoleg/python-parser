<link type="text/css" href="<?php echo SCRIPT;?>standard/css/jquery.fancybox.css" rel="stylesheet"/><span class='gal' data-id='4'></span>
<script src="<?php echo SCRIPT;?>jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="<?php echo SITE.'/'.self::$path;?>/css/style.css" type="text/css" />
<script src="<?php echo SITE.'/'.self::$path;?>/js/script.js"></script>
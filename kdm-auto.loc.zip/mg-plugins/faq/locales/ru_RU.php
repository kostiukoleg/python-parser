<?php
$lang = array(
  "ENTITY_COUNT" => 'Количество',
  "HEADER_MODAL_ADD" => 'Редактор',
  "CLOSE_MODAL" => 'Закрыть',
  "SAVE_BASE" => 'Базовые настройки сохранены',
  "NOT_SAVE_BASE" => 'Не удалось сохранить базовые настройки',
  "SAVE_MODAL" => 'Сохранить',
  "ENTITY_SAVE" => 'Cохранено успешно',
  "ENTITY_DEL_NOT" => 'Не удалось сохранить',
  "ENTITY_DEL" => 'Вопрос-ответ удален',
  "ENTITY_NONE"=>'Отсутствуют вопросы и ответы',
  "ENTITY_SAVE_NOT" => 'Не удалось удалить вопрос-ответ',
  "ADD_MODAL" => 'Добавить вопрос-ответ',
  "ACT_V_ENTITY" => "Включен",
  "ACT_UNV_ENTITY" => "Выключен",
  "SHOW_COUNT_QUEST" => 'Вопросов на странице',
  "ANSWER" => 'Ответ',
);
<?php
$lang = array(
  "ENTITY_COUNT" => 'Кількість',
  "HEADER_MODAL_ADD" => 'Редактор',
  "CLOSE_MODAL" => 'Закрити',
  "SAVE_BASE" => 'Базові налаштування збережені',
  "NOT_SAVE_BASE" => 'Не вдалося зберегти базові налаштування',
  "SAVE_MODAL" => 'Зберегти',
  "ENTITY_SAVE" => 'Збережемо успішно',
  "ENTITY_DEL_NOT" => 'Не вдалося зберегти',
  "ENTITY_DEL" => 'Сутність видалена',
  "ENTITY_NONE"=>'Відсутні записи',
  "ENTITY_SAVE_NOT" => 'Не вдалося видалити сутність',
  "ADD_MODAL" => 'Додати запис',
  "ACT_V_ENTITY" => "Включений",
  "ACT_UNV_ENTITY" => "Виключений",
  "SHOW_COUNT_QUEST" => 'Questions on the page',
);
<?php
$lang = array(
	/***********Админка [Раздел страниц]*************/
	'COMMENTS_MODAL_TITLE' => 'Настройки отзывов',
	'COMMENTS_COUNT' => 'Выводить отзывов',
	'COMMENTS_NAME' => 'Имя',
	'COMMENTS_EMAIL' => 'Email',
	'COMMENTS_COMMENT' => 'Текст отзыва',
	'COMMENTS_APPROVE' => 'Статус',
	'COMMENTS_ACTIONS' => 'Действия',
	'NEWS_NONE' => 'Отзывы отсутствуют',
	'T_TIP_SAVE_COMMENT' => 'Сохранить отзыв',
	'SAVE'=>'Сохранить',
	'T_TIP_COMMENTS_NAME' => 'Имя отправителя',
	'T_TIP_COMMENTS_EMAIL' => 'Email отправителя',
	'T_TIP_COMMENTS_STATUS' => 'Статус отзыва',
	'T_TIP_COMMENTS_COMMENT' => 'Текст отзыва',
	);
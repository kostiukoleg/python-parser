<?php
$lang = array(
  "ENTITY_COUNT" => 'Number',
  "HEADER_MODAL_ADD" => 'Editor',
  "CLOSE_MODAL" => 'Close',
  "SAVE_BASE" => 'Basic settings saved',
  "NOT_SAVE_BASE" => 'Failed to save the basic settings',
  "SAVE_MODAL" => 'Save',
  "ENTITY_SAVE" => 'Save successful',
  "ENTITY_DEL_NOT" => 'Could not save',
  "ENTITY_DEL" => 'Essence removed',
  "ENTITY_NONE"=>'No records',
  "ENTITY_SAVE_NOT" => 'Unable to remove the essence',
  "ADD_MODAL" => 'Add new',
  "ACT_V_ENTITY" => "On",
  "ACT_UNV_ENTITY" => "Off",
  "T_TIP_SHOW_PROPERTY" => "Change the settings",
  "SHOW_PROPERTY" => "Settings",
);

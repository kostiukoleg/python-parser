<?php
$lang = array(
  "ENTITY_COUNT" => 'Количество',
  "HEADER_MODAL_ADD" => 'Редактор',
  "CLOSE_MODAL" => 'Закрыть',
  "SAVE_BASE" => 'Базовые настройки сохранены',
  "NOT_SAVE_BASE" => 'Не удалось сохранить базовые настройки',
  "SAVE_MODAL" => 'Сохранить',
  "ENTITY_SAVE" => 'Cохранено успешно',
  "ENTITY_DEL_NOT" => 'Не удалось сохранить',
  "ENTITY_DEL" => 'Сущность удалена',
  "ENTITY_NONE"=>'Отсутствуют записи',
  "ENTITY_SAVE_NOT" => 'Не удалось удалить сущность',
  "ADD_MODAL" => 'Добавить запись',
  "ACT_V_ENTITY" => "Включен",
  "ACT_UNV_ENTITY" => "Выключен",
  "T_TIP_SHOW_PROPERTY" => "Изменить настройки",
  "SHOW_PROPERTY" => "Настройки"
);